
char * base64_encode(void *data, size_t size);
