var ie4        = document.all?true:false;
var dom4       = document.getElementById?true:false;
var DOM        = true ; /*ie4 || dom4;*/
var baseTarget = 'panel';
var mnuaktiv   = null;
var openMenues = new Array();
var tmr        = 'mnuaktiv=setTimeout(\'hideAll()\',2000)';
var flag       = false;
var menus      = new Array();

function Menu(name) 
{ menus[menus.length]=this;

  this.name=name;
  this.item=new Array();
  this.timeout=2000;

  this.addItem=addItem;
  this.addMenu=addMenu;
  this.show=show;
  this.build=build;
  this.hide=hide;
}

function addItem(url,text) 
{ this.item[this.item.length]=new Item(url,text); }

function addMenu(name,url,text) 
{ this.item[this.item.length]=new Item(url,text,name);
  window[name]=new Menu(name);
  window[name].parent=this;
}

function show(lnk,sub) 
{ if(mnuaktiv) clearTimeout(mnuaktiv);
  lnk.onmouseout=new Function(tmr);
  if(DOM)
    { if(dom4)
       { with( document.getElementById(this.name).style)  
           { position='absolute';
             if(sub) { posLeft=glft(lnk); 
                       posTop=gtop(lnk)+24;
                     }
             else { posLeft=glft(lnk)-2;
		    posTop=gtop(lnk)+lnk.offsetHeight-4;
                  }

             visibility='visible';
           }
       }
      else
       { with( document.all(this.name).style)  
           { position='absolute';
             if(sub) { posLeft=glft(lnk); 
                       posTop=gtop(lnk)+24;
                     }
             else { posLeft=glft(lnk)-2;
		    posTop=gtop(lnk)+lnk.offsetHeight-4;
                  }

             visibility='visible';
           }  
       }
    }
  openMenues[openMenues.length]=this;
}

function glft(l) 
{ if(l.offsetParent) return(l.offsetLeft+glft(l.offsetParent));
                else return(l.offsetLeft);
}

function gtop(l)
{ if(l.offsetParent) return(l.offsetTop+gtop(l.offsetParent));
                else return(l.offsetTop);
}

function buildAll() 
{ for(var i=0;i<menus.length;i++) menus[i].build(); }

function build() 
{ var HTML='';

  for (var i=0; i<this.item.length; i++)
    { var cancelText ='', subMenuText='';
      if(!this.item[i].url)
        { cancelText  = 'onClick="event.cancelBubble=true;return false"';
          subMenuText = ' >';        	
        }
      HTML +=   '<td nowrap>'
             +  '<a href="'+this.item[i].url+'" target="'+baseTarget+'" '
             +      'class="MenuItem" style="width: 100%" '
             +      cancelText
             +      ' onFocus="this.blur()" onMouseOver="hideAll('+this.name+');'
             +      (this.item[i].menu?this.item[i].menu+'.show(this,true);':'')
             +      'clearTimeout(mnuaktiv);" onMouseOut="'+tmr+'">'
             +   this.item[i].text + subMenuText
             +  '</a>'
             + '</td>\n';
    }

  HTML =   '<span id="'+this.name+'" '
         +     'class="MenuStyle" '
         +     'style="position:absolute; width:1px; z-Index:10000; visibility:hidden">'
	 +  '<table border=0 cellspacing=0 cellpadding=0>'
	 +   '<tr>'
         +      HTML
         +   '</tr>'
         +  '</table>'
         + '</span>';

  document.write(HTML);
}

function hideAll(mnu) 
{ var tmpMenues=new Array();
  if(openMenues) 
    { for (var i=0; i<openMenues.length; i++) 
        { if (!mnu || mnu == openMenues[i].parent) 
                 { openMenues[i].hide();
                   hideAll(openMenues[i]);
                 }
	    else tmpMenues[tmpMenues.length]=openMenues[i];
        }
    }

  openMenues=tmpMenues;
}

function hide() 
{ if(DOM)
   { if(dom4) document.getElementById(this.name).style.visibility='hidden'; 
         else document.all(this.name).style.visibility='hidden';
   }
}

function Item(url, text, menu) 
{ this.url=url;
  this.text=text;
  this.menu=menu;
}  

if(DOM) 
{ Main=new Menu('Main');
      Main.addItem('main.html#intro'   ,'introduction');
      Main.addItem('main.html#email'   ,'email');
      Main.addItem('main.html#download','download');
      Main.addItem('main.html#history' ,'history');
	
  Description=new Menu('Description');
      Description.addMenu('SFirst' ,null                       ,'first sector');   
        SFirst.addItem('doc/OE_Dbx_FileStructure.html#first'  ,'usage');
        SFirst.addItem('doc/OE_Dbx_FileHeader.html'           ,'file header');
        SFirst.addItem('doc/OE_Dbx_FileInfo.html'             ,'file info');
      Description.addMenu('SMiddle',null                       ,'middle sector');   
        SMiddle.addItem('doc/OE_Dbx_FileStructure.html#middle','usage');
        SMiddle.addItem('doc/OE_Dbx_Tree.html'                ,'tree');
        SMiddle.addMenu('SInfoObj',null                        ,'info objects');
          SInfoObj.addItem('doc/OE_Dbx_IndexedInfo.html'      ,'indexed info');
          SInfoObj.addItem('doc/OE_Dbx_MessageInfo.html'      ,'message info');
          SInfoObj.addItem('doc/OE_Dbx_FolderInfo.html'       ,'folder info');
        SMiddle.addItem('doc/OE_Dbx_Message.html'             ,'message');
        SMiddle.addItem('doc/OE_Dbx_Deleted.html'             ,'deleted');
        SMiddle.addItem('doc/OE_Dbx_Conditions.html'          ,'conditions');
      Description.addMenu('SLast'  ,null                       ,'last sector');   
        SLast.addItem('doc/OE_Dbx_FileStructure.html#last'    ,'usage');
 	
  Sources=new Menu('Sources');
      Sources.addItem('cppsource.html#howtouse'    ,'how to use'); 
      Sources.addItem('cppsource.html#libraryfiles','oedbx library files'); 
      Sources.addItem('cppsource.html#examples'    ,'examples'); 

  document.onclick=hideAll;
  buildAll();
}
