#ifndef Ex1H
#define Ex1H
//***************************************************************************************
void ExtractAllMessages(const char * fileName, const char * logFile);  

void ShowAllDomains(const char * fileName, const char * logFile);  

void ShowAllLocaleFolders(const char * fileName, const char * logFile);  
//***************************************************************************************
#endif
 
